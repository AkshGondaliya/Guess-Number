package com.example.guess_number;
import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class gameController {
	int target=(int)(Math.random()*100+1);
	
	int score=0;
	int attemptsLeft;
	
	@GetMapping("/")
	public String startGame(Model model) {
		attemptsLeft=5;
		model.addAttribute("attempts", this.getAttemptsLeft());
		model.addAttribute("score", this.getScore());
		model.addAttribute("mess","Guess The Number Between 1 To 100.");
		model.addAttribute("gameOver", false);
		return "game";
	}
	
	@PostMapping("/guess")
	public String guess(@RequestParam("userguess") int userguess,Model model) {
		attemptsLeft--;
		if(userguess==target) {
			model.addAttribute("mess", "Congratulation! You Guessed Correct Number.");
			model.addAttribute("gameOver",true);
			score++;
		}
		else if(attemptsLeft<=0){
			model.addAttribute("mess", "Your Attempts are finished.");
			model.addAttribute("gameOver",true);
		}else {
			String res=userguess<target?"Too, Low.":"Too, High";
			model.addAttribute("mess", res);
		}
		model.addAttribute("attempts", this.getAttemptsLeft());
		model.addAttribute("score", this.getScore());
		return "game";
		
	}

	public int getScore() {
		return score;
	}

	

	public int getAttemptsLeft() {
		return attemptsLeft;
	}

	
}
