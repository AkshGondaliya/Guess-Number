package com.example.guess_number;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuessNumberApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuessNumberApplication.class, args);
	}

}
