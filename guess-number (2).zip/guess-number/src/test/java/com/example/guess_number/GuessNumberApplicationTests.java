package com.example.guess_number;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuessNumberApplicationTests {

	@Test
	void contextLoads() {
	}

}
